from django.http import HttpResponse
from django.shortcuts import redirect,render



def unauthenticated_user(view_func):
    def wrapper_func(request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect('home')
        
        else:
            return view_func(request, *args, **kwargs)
    
    return wrapper_func
        


def allowed_users(allowed_roles=[]):
    def decorator(view_func):
        def wrapper_func(request, *args, **kwargs):
            group = None
            
            # Debugging: Print user info
            print(f"User: {request.user}, Groups: {request.user.groups.all()}")

            # Check if the user is part of any group
            if request.user.groups.exists():
                group = request.user.groups.all()[0].name
                print(f"Group found: {group}")
            else:
                print("No group found.")
                return HttpResponse("You do not belong to any group.")

            is_approved = False

            # Determine if the user is approved based on their profile
            if group == 'student':
                if hasattr(request.user, 'studentprofile'):
                    is_approved = request.user.studentprofile.is_approved
                    print(f"Student approval status: {is_approved}")
                else:
                    print("No student profile found.")
                    return HttpResponse("Student profile not found.")
            elif group == 'teacher':
                if hasattr(request.user, 'teacherprofile'):
                    is_approved = request.user.teacherprofile.is_approved
                    print(f"Teacher approval status: {is_approved}")
                else:
                    print("No teacher profile found.")
                    return HttpResponse("Teacher profile not found.")

            # Check approval status and group authorization
            if is_approved:
                if group in allowed_roles:
                    return view_func(request, *args, **kwargs)
                else:
                    print(f"User is not authorized for role: {allowed_roles}")
                    return HttpResponse("You are not authorized to view this page.")
            else:
                print("User is pending approval.")
                return render(request,"approval_pending.html")
        
        return wrapper_func
    return decorator


def admin_only(view_func):
    def wrapper_function(request, *args, **kwargs):
        # Check if user is authenticated
        if not request.user.is_authenticated:
            return redirect('login')  # Adjust to your login URL name

        group = None
        if request.user.groups.exists():
            group = request.user.groups.all()[0].name

            if group == 'teacher':
                return redirect('teachermenu')
            elif group == 'student':
                return redirect('studentmenu')
            elif group == 'admin':
                return view_func(request, *args, **kwargs)

        # If the user does not belong to any of the groups
        return HttpResponse("You are not authorized to view this page.")
    
    return wrapper_function


def profile_approved(view_func):
    def wrapper_func(request, *args, **kwargs):
        if request.user.is_authenticated:
            if hasattr(request.user, 'Teacherprofile'):
                if not request.user.Teacherprofile.is_approved:
                    print("Teacher account is not approved.")
                    return HttpResponse("Your teacher account is pending approval by admin.")
            elif hasattr(request.user, 'Studentprofile'):
                if not request.user.Studentprofile.is_approved:
                    print("Student account is not approved.")
                    return HttpResponse("Your student account is pending approval by admin.")
        return view_func(request, *args, **kwargs)
    return wrapper_func

